---
title: "Placeholder Product"
description: "This is just a test."
image: "/images/uploads/test.jpg"
price: 100
status: "active"
---
